﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Example
{
    public enum Event
    {
        OneWay = 1,

        Return = 2,

        PushMessage = 3,

        Bin = 4,
    }
}
