﻿namespace ShoppingWebCrawler.Host
{
    using AppStart;
    using System;


    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            return InitApp.Init(args);
        }
    }
}
