﻿
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShoppingWebCrawler.Host.UI;
using ShoppingWebCrawler.Cef.Core;
using ShoppingWebCrawler.Cef.Framework;


using System.Net;

namespace ShoppingWebCrawler.Host
{
    /// <summary>
    /// 无头模式的窗口入口
    /// 1 加载 一个空白的cefbrowser 对象
    /// 2 对配置中的站点列表进行 Next方式打开
    /// 3 Next 链 完毕后，开始随机定时，到触发点后，继续轮询URL
    /// </summary>
    public partial class HeadLessMainForm : BaseForm
    {

        #region 属性
        public CefBrowser WebBrowser { get; private set; }

        /// <summary>
        /// 定时调度器
        /// </summary>
        private Timer _timer;
        /// <summary>
        /// 下一次 触发加载全部电商平台的时间
        /// </summary>
        private DateTime _nextInvokeAllSuuportPlatforms = DateTime.Now;

        /// <summary>
        /// 是否正在轮式加载平台链
        /// </summary>
        private bool _is_running_invoke_linkes = false;

        /// <summary>
        /// 当前遍历的列表的偏移位置
        /// </summary>
        private int _cursor_Links = 0;

        /// <summary>
        /// 一个简单的随机数生成器
        /// </summary>
        private Random _randor = new Random(DateTime.Now.Millisecond);
        #endregion


        /// <summary>
        /// 初始化浏览器
        /// </summary>
        /// <param name="browser"></param>
        private void InitWebBrowser(CefWebBrowser browser)
        {
            browser.IsCanShowContextMenu = false;
            browser.IsCanShowPopWindow = false;
            //文档加载完毕后触发的事件
            browser.LoadEnd += OnWebBrowserLoadEnd;
        }



        public HeadLessMainForm()
        {
            InitializeComponent();

            this.Load += HeadLessMainForm_Load;
        }



        /// <summary>
        /// 浏览器加载完毕后的一个回调函数
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnWebBrowserLoadEnd(object sender, LoadEndEventArgs e)
        {
            var browser = sender as CefWebBrowser;
            var code = e.HttpStatusCode;
            if (code != (int)HttpStatusCode.OK)
            {
                Logging.Logger.WriteToLog(new Logging.LogEventArgs { LogMessage = string.Format("未能从指定的URL 成功获取网页！状态码不是200.URL: {0} ", browser.Address) });
            }

            //超过阈值 那么表示轮链完毕一次周期
            if (_cursor_Links >= GlobalContext.SupportPlatforms.Count)
            {
                //重置状态位
                _is_running_invoke_linkes = false;
                //随机生成浏览器进行轮链的间隔（分钟）
                int browserLoopLinksTimeSpan = _randor.Next(5, 10);
                _nextInvokeAllSuuportPlatforms = DateTime.Now.AddSeconds(browserLoopLinksTimeSpan);

            }


            //如果未到最后一个偏移量  那么继续触发下一个
            string nextSiteUrl = GlobalContext.SupportPlatforms[_cursor_Links].SiteUrl;
            this.NavigateToUrl(nextSiteUrl);

        }

        /// <summary>
        /// 窗体加载的事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HeadLessMainForm_Load(object sender, EventArgs e)
        {
            if (null == WebBrowser)
            {
                //WebBrowser = new CefWebBrowser();
                //InitWebBrowser(WebBrowser);
                // Instruct CEF to not render to a window at all.
                CefWindowInfo cefWindowInfo = CefWindowInfo.Create();
                cefWindowInfo.SetAsWindowless(IntPtr.Zero,true);

            }
            _timer = new Timer();
            _timer.Interval = 1000;
            _timer.Tick += handler_timer_Tick;
            _timer.Start();
        }
        /// <summary>
        /// 计时器触发的事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void handler_timer_Tick(object sender, EventArgs e)
        {
            if (_is_running_invoke_linkes == true)
            {
                return;
            }

            //触发加载平台列表
            if (DateTime.Now>=_nextInvokeAllSuuportPlatforms )
            {
                this.BeginLoadAllSupportPlatforms();
                this._is_running_invoke_linkes = true;
            }
        }
        /// <summary>
        /// 开始轮式 触发链
        /// </summary>
        private void BeginLoadAllSupportPlatforms()
        {
            if (null == GlobalContext.SupportPlatforms || GlobalContext.SupportPlatforms.Count <= 0)
            {
                return;
            }
            _cursor_Links = 0;
            string firstSiteUrl = GlobalContext.SupportPlatforms[_cursor_Links].SiteUrl;
            string logMsg = string.Format("CEF开始发送对 {0} 的请求 .", firstSiteUrl);
            Logging.Logger.WriteToLog(logMsg);

            this.NavigateToUrl(firstSiteUrl);
        }
        /// <summary>
        /// 转到指定的网址
        /// </summary>
        /// <param name="url"></param>
        private void NavigateToUrl(string url)
        {
            //开始触发加载首个网址 每当加载完毕时候 触发的事件中 进行加载下一个
            this.WebBrowser.Browser.GetMainFrame().LoadUrl(url);

        }

    }
}
